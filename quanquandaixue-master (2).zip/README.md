圈圈带学

1. globalData={
    userInfo:dict
    hasUserInfo:bool
   }
